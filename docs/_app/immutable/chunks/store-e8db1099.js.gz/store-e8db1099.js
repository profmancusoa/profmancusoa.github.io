import{w as a}from"./index-7571d01b.js";const s=a([]);export{s as a};
