import{w as a}from"./index-b5efc5e9.js";const s=a([]);export{s as a};
