import{w as a}from"./index-efb87244.js";const s=a([]);export{s as a};
