import{w as a}from"./index-fc8f75bc.js";const s=a([]);export{s as a};
