import{w as a}from"./index-3354d17e.js";const s=a([]);export{s as a};
