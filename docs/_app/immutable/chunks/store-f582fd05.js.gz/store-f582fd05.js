import{w as a}from"./index-921bc2ca.js";const s=a([]);export{s as a};
