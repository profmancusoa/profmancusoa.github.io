import{w as a}from"./index-c824edcc.js";const s=a([]);export{s as a};
