import{w as a}from"./index-c705e0e1.js";const s=a([]);export{s as a};
