import{w as a}from"./index-13540941.js";const s=a([]);export{s as a};
